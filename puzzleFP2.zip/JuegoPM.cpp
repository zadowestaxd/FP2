#include "JuegoPM.h"

int menu() {
	int opcion;
	cout << endl << "1.Resolver un puzzle 1D" << endl
		<< "2.Resolver un puzzle 2D" << endl
		<< "3.A�adir un puzzle al catalogo" << endl
		<< "0.Salir" << endl << endl
		<< "Elige una opcion:" << endl;
	cin >> opcion;

	while (opcion > 3 || opcion < 0) {
		cout << "Opcion no valida, selecciona otra:" << endl;
		cin >> opcion;
	}

	return opcion;
}

void mainPuzzlesReunidos() {
	tPuzzlesReunidos pr;
	tPuzzle* puzzle = nullptr;

	inicializar(pr);
	cargar(pr);
	bool end = false;
	while (!end) {
		switch (menu()) {
			case(1): {
				int opcion = elegirPuzzle(pr[0]);
				pr[0].listas[opcion - 1]->modo = "1D";
				puzzle = pr[0].listas[opcion - 1];
				mainPuzzle(*puzzle);
				break; }
			case(2): {
				int opcion = elegirPuzzle(pr[1]);
				pr[1].listas[opcion - 1]->modo = "2D";
				puzzle = pr[1].listas[opcion - 1];
				mainPuzzle(*puzzle);
				break; }
			case(3): { cout << "Que tipo de puzzle desea agregar? 1 - 1D, 2 - 2D:" << endl;
				int t;
				cin >> t;
				if (t == 1) {
					cout << "Diga el nombre del puzzle:" << endl;
					string nom;
					cin >> nom;
					pr[0].listas[pr[0].cont]->nombre = nom;
					cout << "Diga el nombre del archivo:" << endl;
					string fich;
					cin >> fich;
					pr[0].listas[pr[0].cont]->fichero = fich;

					insertarOrdenado(pr[0], pr[0].listas[pr[0].cont]); break;

				}
				else if (t == 2) {
					cout << "Diga el nombre del puzzle:" << endl;
					string nom;
					cin >> nom;
					pr[1].listas[pr[1].cont]->nombre = nom;
					cout << "Diga el nombre del archivo:" << endl;
					string fich;
					cin >> fich;
					pr[1].listas[pr[1].cont]->fichero = fich;

					insertarOrdenado(pr[1], pr[1].listas[pr[1].cont]); break;

				}
			}
			case(0): {
				end = true; break;
			}
		}
	}
}	