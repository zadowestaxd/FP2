#include "ListaPuzzles.h"

#ifndef JUEGO_PM
#define JUEGO_PM

#endif

int menu();
int elegirPuzzle(tListaPuzzles& lp);
void mainPuzzlesReunidos();