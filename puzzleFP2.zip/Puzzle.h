#include "MatrizChar.h"

#ifndef JUEGO_PM
#define JUEGO_PM

typedef struct {
    string nombre, modo, fichero;
    tMatrizChar imagen, imagenFinal;
    int maxAcciones;
    int contador;
}tPuzzle;

void mainPuzzle(tPuzzle& jpm);
bool iniciar(tPuzzle& jpm, string modo);
bool cargar(tPuzzle& jpm, string modo);
void mostrar(tPuzzle const& jpm);
bool jugar(tPuzzle& jpm);
void accion(tPuzzle& jpm);

#endif

