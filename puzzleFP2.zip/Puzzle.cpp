#include "Puzzle.h"

void mainPuzzle(tPuzzle& jpm) {

	iniciar(jpm, jpm.modo);
	jugar(jpm);
}

bool iniciar(tPuzzle& jpm, string modo) {
	bool ok = false;
	jpm.contador = 0;
	jpm.modo = modo;
	if (cargar(jpm, modo)) ok = true;
	return ok;
}

bool cargar(tPuzzle& jpm, string modo) {
	bool ok = false;
	ifstream im(jpm.fichero);
	if (cargar(jpm.imagen, im) && cargar(jpm.imagenFinal, im)) ok = true;
	im >> jpm.maxAcciones;
	return ok;
}

void mostrar(tPuzzle const& jpm) {
	for (int i = 0; i < jpm.imagen.numFilas; i++) {
		for (int j = 0; j < jpm.imagen.numCols; j++) {
		colorCTA(jpm.imagen.elementos[i][j], jpm.imagen.elementos[i][j]);
			cout << jpm.imagen.elementos[i][j];
		colorCTA(15, 0);
		}
		cout << endl;
	}

	cout << endl << endl;
	for (int i = 0; i < jpm.imagenFinal.numFilas; i++) {
		for (int j = 0; j < jpm.imagenFinal.numCols; j++) {
			colorCTA(jpm.imagenFinal.elementos[i][j], jpm.imagenFinal.elementos[i][j]);
			cout << jpm.imagenFinal.elementos[i][j];
			colorCTA(15, 0);
		}
		cout << endl;
	}
	colorCTA(15, 0);
	cout << "Numero de intentos restantes: " << jpm.maxAcciones - jpm.contador << endl;
}

bool jugar(tPuzzle& jpm) {
	bool end = false;

	while (!end) {
		mostrar(jpm);
		accion(jpm);
		jpm.contador++;
		if (jpm.imagen == jpm.imagenFinal) {
			mostrar(jpm);
			cout << "ENHORABUENA, HA GANADO" << endl;
			pausa();
			end = true;
		}
		if (jpm.contador == jpm.maxAcciones) {
			end = true;
			mostrar(jpm);
			cout << "Te quedan 0 intentos" << endl;
			pausa();
		}
		borrar();
	}
	return end;
}

void accion(tPuzzle& jpm) {
	string opcion;

	cout << "Escriba la accion deseada: ";
	cin >> opcion;
	if (jpm.modo == "1D") {
		if (opcion == "SF" || opcion == "sf") {
			int f1, f2;
			cout << "Escriba las filas a cambiar: ";
			cin >> f1;
			cin >> f2;
			if (!swapF(jpm.imagen, f1, f2)) {
				cout << "Filas fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else if (opcion == "SC" || opcion == "sc") {
			int c1, c2;
			cout << "Escriba las columnas a cambiar: ";
			cin >> c1;
			cin >> c2;
			if (!swapC(jpm.imagen, c1, c2)) {
				cout << "Columnas fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else if (opcion == "SD" || opcion == "sd") {
			int d;
			cout << "Escriba la diagonal a cambiar: ";
			cin >> d;
			if (!swapD(jpm.imagen, d)) {
				cout << "Diagonal fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else if (opcion == "VF" || opcion == "vf") {
			int f;
			cout << "Escriba la fila a voltear: ";
			cin >> f;
			if (!voltearF(jpm.imagen, f)) {
				cout << "Fila fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else if (opcion == "VC" || opcion == "vc") {
			int c;
			cout << "Escriba la columna a voltear: ";
			cin >> c;
			if (!voltearC(jpm.imagen, c)) {
				cout << "Columna fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else if (opcion == "VD" || opcion == "vd") {
			int d;
			cout << "Escriba la diagonal a voltear: ";
			cin >> d;
			if (!voltearD(jpm.imagen, d)) {
				cout << "Diagonal fuera del rango" << endl;
				jpm.contador -= 1;
			}
		}
		else {
			cout << "Operacion desconocida";
			pausa();
			jpm.contador -= 1;
		}
	}

	else if (jpm.modo == "2D") {
		if (opcion == "VV" || opcion == "vv") {
			voltearV(jpm.imagen);
		}
		else if (opcion == "VH" || opcion == "vh") {
			voltearH(jpm.imagen);
		}
		else if (opcion == "RD" || opcion == "rd") {
			rotarD(jpm.imagen);
		}
		else if (opcion == "SA" || opcion == "sa") {
			tCoor coor1, coor2;
			int fila, columna;
			cout << "Escriba las coordenadas a cambiar: ";
			cout << "coor1 fila:";
			cin >> coor1.fila;
			cout << "coor1 columna:";
			cin >> coor1.col;
			cout << "coor2 fila:";
			cin >> coor2.fila;
			cout << "coor2 columna:";
			cin >> coor2.col;
			if (!swapAdy(jpm.imagen, coor1, coor2)) {
				cout << "No se ha podido realizar la operaci�n";
				jpm.contador -= 1;
			}
		}
		else if (opcion == "VD" || opcion == "vd") {
			if (!VoltearID(jpm.imagen)) {
				cout << "No se puede voltear ya que la matriz no es cuadrada";
				jpm.contador -= 1;
			}
		}
		else {
			cout << "Operacion desconocida";
			pausa();
			jpm.contador -= 1;
		}
	}
}