#include "JuegoPM.h"

#ifdef _DEBUG

#define DBG_NEW new(_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DBG_NEW

#endif

int main() {
	mainPuzzlesReunidos();
	return 0;
}