#include "MatrizChar.h"

bool cargar(tMatrizChar& mat, istream& ent) {
	bool ok = true;
	ent >> mat.numFilas;
	ent >> mat.numCols;
	for (int i = 0; i < mat.numFilas; i++) {
		for (int j = 0; j < mat.numCols; j++) {
			ent >> mat.elementos[i][j];
		}
	}
	return ok;
}

bool operator == (tMatrizChar const& mat1, tMatrizChar const& mat2) {
	bool iguales = true;
	int f = 0, c;
	while (mat1.numFilas == mat2.numFilas && f < mat1.numFilas && iguales) {
		c = 0;
		while (mat1.numCols == mat2.numCols && c < mat1.numCols && iguales) {
			if (mat1.elementos[f][c] != mat2.elementos[f][c]) iguales = false;
			else c++;
		}
		if (iguales) f++;
	}
	return iguales;
}

bool swap(tMatrizChar& mat, tCoor pos1, tCoor pos2) {
	bool ok = false;
	int aux;
	aux = mat.elementos[pos1.fila][pos1.col];

	if (coorInRange(mat, pos1) && coorInRange(mat, pos2)) {
		mat.elementos[pos1.fila][pos1.col] = mat.elementos[pos2.fila][pos2.col];
		mat.elementos[pos2.fila][pos2.col] = aux;
		ok = true;
	}
	return ok;
}

bool swapF(tMatrizChar& mat, int f1, int f2) {
	bool ok = false;

	if (f1 <= mat.numFilas && f1 >= 0 && f2 <= mat.numFilas && f2 >= 0) {
		tCoor a, b;
		a.fila = f1;
		b.fila = f2;

		for (int i = 0; i < mat.numCols; i++) {
			a.col = i;
			b.col = i;
			swap(mat, a, b);
		}
		ok = true;
	}
	return ok;
}

bool swapC(tMatrizChar& mat, int c1, int c2) {
	bool ok = false;

	if (c1 <= mat.numCols && c1 >= 0 && c2 <= mat.numCols && c2 >= 0) {
		tCoor a, b;
		a.col = c1;
		b.col = c2;

		for (int i = 0; i < mat.numCols; i++) {
			a.fila = i;
			b.fila = i;
			swap(mat, a, b);
		}
		ok = true;
	}
	return ok;
}

bool swapD(tMatrizChar& mat, int d) {
	bool ok = false;
	tCoor a, b;
	int i = d, j = 0;
	if (d > 0) {
		int i = 0, j = 0;
		while (i < mat.numFilas && j < mat.numCols) {
			a.fila = i;
			b.col = i;
			a.col = j + d;
			b.fila = j + d;
			swap(mat, a, b);
			i++;
			j++;
		}
		ok = true;
	}

	else {
		d = -d;
		int i = 0;
		int j = 0;
		while (i < mat.numFilas && j < mat.numCols) {
			a.col = i;
			b.fila = i;
			a.fila = j + d;
			b.col = j + d;
			swap(mat, a, b);
			i++;
			j++;
		}
		ok = true;
	}
	return ok;
}

bool voltearF(tMatrizChar& mat, int f) {
	bool ok = false;
	tCoor a, b;
	if (f <= mat.numFilas && f >= 0) {
		for (int i = 0; i < mat.numCols / 2; i++) {
			a.fila = f;
			a.col = i;
			b.fila = f;
			b.col = mat.numCols - i - 1;
			swap(mat, a, b);
		}
		ok = true;
	}
	return ok;
}

bool voltearC(tMatrizChar& mat, int c) {
	bool ok = false;
	tCoor a, b;

	if (c <= mat.numCols && c >= 0) {
		for (int i = 0; i < mat.numFilas / 2; i++) {
			a.fila = i;
			a.col = c;
			b.fila = mat.numFilas - i - 1;
			b.col = c;
			swap(mat, a, b);
		}
		ok = true;
	}
	return ok;
}

bool voltearD(tMatrizChar& mat, int d) {
	bool ok = false;
	tCoor a, b;

	if (d < mat.numFilas && d < mat.numCols && d > -mat.numFilas && d > -mat.numCols) {
		int i = 0, j = 1;
		while (i <= mat.numFilas / 2 && j <= mat.numCols / 2) {
			if (d >= 0) {
				a.fila = i;
				a.col = d + i;
				b.fila = mat.numCols - d - j;
				b.col = mat.numCols - j;
				swap(mat, a, b);
			}
			else if (d < 0) {
				int dn = -d;
				a.fila = dn + i;
				a.col = i;
				b.fila = mat.numFilas - j;
				b.col = mat.numFilas - dn - j;
				swap(mat, a, b);
			}
			i++, j++;
		}
		ok = true;
	}
	return ok;
}

void voltearV(tMatrizChar& mat) {
	for (int i = 0; i < mat.numFilas; i++) {
		voltearF(mat, i);
	}
}

void voltearH(tMatrizChar& mat) {
	for (int i = 0; i < mat.numCols; i++) {
		voltearC(mat, i);
	}
}

void rotarD(tMatrizChar& mat) {
	tMatrizChar aux = mat;
	aux.numFilas = mat.numCols;
	aux.numCols = mat.numFilas;

	for (int i = 0; i < mat.numFilas; i++) {
		for (int j = 0; j < mat.numCols; j++) {
			mat.elementos[i][j] = aux.elementos[mat.numFilas - j - 1][i];
		}
	}
}

bool swapAdy(tMatrizChar& mat, tCoor pos1, tCoor pos2) {
	bool ok = false;
	int aux;
	if (coorInRange(mat, pos1) && coorInRange(mat, pos2)) {
		for (int i = 0; i < mat.numFilas; i++) {
			for (int j = 0; j < mat.numCols; j++) {
				tCoor p1, p2;
				p1.fila = pos1.fila + incF[i];
				p1.col = pos1.col + incC[j];
				p2.fila = pos2.fila + incF[i];
				p2.col = pos2.col + incC[j];
				swap(mat, p1, p2);
			}
		}
	}
	return ok;
}

bool VoltearID(tMatrizChar& mat) {
	bool ok = false;
	if (mat.numFilas == mat.numCols) {
		int d = 1;
		while (d < mat.numFilas) {
			swapD(mat, d);
			d++;
		}
		ok = true;
	}
	return ok;
}

bool coorInRange(tMatrizChar mat, tCoor pos) {
	bool ok = false;
	if (pos.fila < mat.numFilas && pos.fila >= 0 && pos.col < mat.numCols && pos.col >= 0) ok = true;
	return ok;
}