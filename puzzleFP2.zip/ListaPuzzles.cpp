#include "ListaPuzzles.h"

void inicializar(tPuzzlesReunidos& jr) {
	
	for (int i = 0; i < 2; i++) {
		jr[i].cont = 0;
		for (int j = 0; j < MAX_PUZZLES; j++) {
			jr[i].listas[j] = new tPuzzle;
		}
	}
}

bool cargar(tPuzzlesReunidos& jr) {
	ifstream datos;
	bool ok = false;
	datos.open("datosPuzzles.txt");
	if (datos.is_open()) {
		for (int i = 0; i < 2; i++) {
			int c;
			datos >> c;
			jr[i].cont = c;
			string aux;
			string fich;
			for (int j = 0; j < c; j++) {
				//getline(datos, aux);
				datos.ignore();
				getline(datos, jr[i].listas[j]->nombre);
				datos >> fich;
				jr[i].listas[j]->fichero = fich;
				cargar(*(jr[i].listas[j]), jr[i].listas[j]->modo);
			}
		}
		ok = true;
	}
	else {
		cout << "No se ha podido leer la lista de Puzzles." << endl;
	}
	return ok;
}

void guardar(const tPuzzlesReunidos& lp) {
	ofstream datos;
	datos.open("datosPuzzles.txt");
	if(datos.is_open()){
		for (int i = 0; i < lp[0].cont;i++) {
			datos << lp[0].cont;
			datos << lp[0].listas[i]->nombre;
			datos << lp[0].listas[i]->fichero;
		}
		for (int i = 0; i < lp[1].cont; i++) {
			datos << lp[1].cont;
			datos << lp[1].listas[i]->nombre;
			datos << lp[1].listas[i]->fichero;
		}
	}
}

int elegirPuzzle(tListaPuzzles& lp) {
	int numPuzzle;

	for (int i = 0; i < lp.cont; i++) {
		cout << i + 1 << " " << lp.listas[i]->nombre << " con un maximo de "
			<< lp.listas[i]->maxAcciones << " movimientos" << endl;
	}
	cout << "-1 Ordenar la lista de mayor a menor" << endl;
	cout << "-2 Ordenar la lista de menor a mayor" << endl;
	
	cin >> numPuzzle;

	while(numPuzzle < 0 || numPuzzle > lp.cont) {
		if (numPuzzle == -1) {
			for (int i = lp.cont-1; i >= 0; i--) {
				cout << i + 1 << " " << lp.listas[i]->nombre << " con un maximo de "
					<< lp.listas[i]->maxAcciones << " movimientos" << endl;
			}
		}
		if(numPuzzle == -2){
			for (int i = 0; i < lp.cont; i++) {
				cout << i + 1 << " " << lp.listas[i]->nombre << " con un maximo de "
					<< lp.listas[i]->maxAcciones << " movimientos" << endl;
			}
		}
		else {
			cout << "Opcion fuera del rango, elige otra:" << endl;
		}
		cin >> numPuzzle;
	}
	return numPuzzle;
}

bool insertarOrdenado(tListaPuzzles& lp, tPuzzle* p) {
	bool ok = false;
	if (lp.cont == MAX_PUZZLES) {
		cout << "Lista de puzzles llena" << endl;
	}
	else {
		lp.listas[lp.cont] = p;
		int i = lp.cont;
	/*	while (i >= 2) {
			if (p->maxAcciones < lp.listas[i - 2]->maxAcciones) {
				lp.listas[i - 1] = lp.listas[i - 2];
				lp.listas[i - 2] = p;
			}
			i--;
		} */
		cargar(*p, p->modo);
		lp.cont++;
		
		ok = true;
	}
	return ok;
}

bool buscar(const tListaPuzzles& lp, tPuzzle* p, int& pos) {
	bool ok = false;
	// Devuelve el �ndice o -1 si no se ha encontrado
	int i = 0;
	bool encontrado = false;
	while ((i < lp.cont) && !encontrado) {
		if (p->nombre == lp.listas[i]->nombre) {
			pos = i;
			encontrado = true;
		}
		else {
			i++;
		}
	}
	if (!encontrado) {
		pos = -1;
	}
	return ok;
} 