#include "Puzzle.h"

#ifndef LISTAPUZZLES_H
#define LISTAPUZZLES_H

const int MAX_PUZZLES = 100;

typedef tPuzzle* tPuzzlePtr;

typedef struct {
	int cont;
	tPuzzlePtr listas[MAX_PUZZLES];
}tListaPuzzles;

typedef tListaPuzzles tPuzzlesReunidos[2];

#endif

void inicializar(tPuzzlesReunidos& jr);
bool cargar(tPuzzlesReunidos& jr);
void guardar(const tPuzzlesReunidos& lp);
int elegirPuzzle(tListaPuzzles& lp);
bool insertarOrdenado(tListaPuzzles& lp, tPuzzle* p);
bool buscar(const tListaPuzzles& lp, tPuzzle* p, int& pos);
